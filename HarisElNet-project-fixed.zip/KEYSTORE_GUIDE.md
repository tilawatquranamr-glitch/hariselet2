# دليل إنشاء واستخدام مفتاح التوقيع (Keystore Guide) 🔑

يشرح هذا الدليل كيفية إنشاء مفتاح توقيع رقمي لتطبيق **Haris El Net** وتجهيز نسخة الإنتاج (Release APK / Bundle) الموقعة والجاهزة للنشر.

---

### 1. توليد ملف المفتاح (Keystore) عبر سطر الأوامر

افتح الطرفية (Terminal) في مجلد المشروع ونفّذ الأمر التالي باستخدام أداة `keytool` المدمجة في حزمة JDK:

```bash
keytool -genkeypair -v \
  -keystore release.keystore \
  -alias haris_el_net_key \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -storetype JKS
```

* سيُطلب منك إدخال كلمة مرور للمفتاح (احفظها جيداً).
* أدخل اسمك أو اسم المؤسسة والبيانات المطلوبة.
* سيتم إنشاء ملف باسم `release.keystore`.

---

### 2. تهيئة بيانات التوقيع بأمان

#### الطريقة الأولى: عبر ملف `gradle.properties` المحلي
أضف الأسطر التالية إلى ملف `gradle.properties` (أو في المسار الشخصي `~/.gradle/gradle.properties` لتفادي رفعه إلى Git):

```properties
KEYSTORE_FILE=../release.keystore
KEYSTORE_PASSWORD=كلمة_مرور_المستودع
KEY_ALIAS=haris_el_net_key
KEY_PASSWORD=كلمة_مرور_المفتاح
```

> **تنبيه أمني هام**: تأكد من وجود `*.keystore` و `*.jks` في ملف `.gitignore` حتى لا يتم تسريب المفتاح البرمجي إلى مستودعات Git العامة.

#### الطريقة الثانية: عبر متغيرات البيئة (CI/CD مثل GitHub Actions)
يمكنك تمرير نفس المتغيرات كمتغيرات بيئة دون الحاجة لكتابتها في أي ملف:
* `KEYSTORE_FILE`
* `KEYSTORE_PASSWORD`
* `KEY_ALIAS`
* `KEY_PASSWORD`

---

### 3. بناء نسخة الإنتاج الموقعة والمضغوطة

بعد ضبط المفاتيح، شغّل أمر البناء التالي:

```bash
./gradlew assembleRelease
```

* سيقوم المترجم بتفعيل تقليص الموارد (`shrinkResources`) وحذف الأكواد الزائدة (`minifyEnabled / R8`).
* ستجد ملف الـ APK الموقع والنهائي في المسار:
  `app/build/outputs/apk/release/app-release.apk`
