package com.netswitch.app

import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.tabs.TabLayout
import com.netswitch.app.databinding.ActivityDataUsageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * شاشة استهلاك الإنترنت الحقيقي في مشروع "حارس النت".
 * توفر إحصائيات استهلاك شبكتي الجوال والـ Wi-Fi، وتفصيل لكل تطبيق، ومخطط بياني Canvas وتنبيه الحد اليومي.
 */
class DataUsageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDataUsageBinding
    private lateinit var helper: NetworkStatsHelper
    private lateinit var prefs: Prefs
    private lateinit var usageAdapter: AppUsageAdapter

    private var currentTabIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataUsageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        helper = NetworkStatsHelper(this)
        prefs = Prefs.getInstance(this)

        setupToolbar()
        setupRecyclerView()
        setupDailyLimitSection()
        setupTabs()
        setupPermissionButton()
    }

    override fun onResume() {
        super.onResume()
        checkPermissionAndLoadData()
    }

    private fun setupToolbar() {
        binding.toolbarUsage.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        usageAdapter = AppUsageAdapter(packageManager)
        binding.rvAppUsage.apply {
            layoutManager = LinearLayoutManager(this@DataUsageActivity)
            adapter = usageAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun setupPermissionButton() {
        binding.btnGrantUsagePermission.setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر فتح صفحة الإعدادات مباشرة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupTabs() {
        binding.tabLayoutPeriod.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentTabIndex = tab?.position ?: 0
                loadAppUsageForTab(currentTabIndex)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {
                loadAppUsageForTab(currentTabIndex)
            }
        })
    }

    private fun setupDailyLimitSection() {
        val currentLimit = prefs.dailyMobileLimitMb
        if (currentLimit > 0L) {
            binding.etDailyLimit.setText(currentLimit.toString())
        }

        binding.btnSaveLimit.setOnClickListener {
            val text = binding.etDailyLimit.text?.toString()?.trim()
            val limitMb = text?.toLongOrNull() ?: 0L
            prefs.dailyMobileLimitMb = limitMb

            if (limitMb > 0L) {
                scheduleDailyLimitWorker()
            } else {
                cancelDailyLimitWorker()
            }

            Toast.makeText(this, R.string.usage_limit_saved_toast, Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleDailyLimitWorker() {
        val workRequest = PeriodicWorkRequestBuilder<DailyLimitWorker>(
            15, TimeUnit.MINUTES
        ).build()

        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            DailyLimitWorker.UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            workRequest
        )
    }

    private fun cancelDailyLimitWorker() {
        WorkManager.getInstance(applicationContext).cancelUniqueWork(
            DailyLimitWorker.UNIQUE_WORK_NAME
        )
    }

    private fun checkPermissionAndLoadData() {
        if (!helper.hasUsageStatsPermission()) {
            binding.layoutPermissionRequired.visibility = View.VISIBLE
            binding.scrollUsageContent.visibility = View.GONE
        } else {
            binding.layoutPermissionRequired.visibility = View.GONE
            binding.scrollUsageContent.visibility = View.VISIBLE
            loadTodayOverviewAndChart()
            loadAppUsageForTab(currentTabIndex)
        }
    }

    private fun loadTodayOverviewAndChart() {
        lifecycleScope.launch {
            try {
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                val startOfDay = cal.timeInMillis
                val now = System.currentTimeMillis()

                val mobileUsage = helper.querySummaryForNetwork(
                    ConnectivityManager.TYPE_MOBILE,
                    startOfDay,
                    now
                )
                val wifiUsage = helper.querySummaryForNetwork(
                    ConnectivityManager.TYPE_WIFI,
                    startOfDay,
                    now
                )

                val totalToday = mobileUsage.totalBytes + wifiUsage.totalBytes
                binding.tvTotalUsageToday.text = DataFormatter.formatBytes(this@DataUsageActivity, totalToday)

                // بيانات الجوال
                binding.tvMobileTotal.text = DataFormatter.formatBytes(this@DataUsageActivity, mobileUsage.totalBytes)
                val mobileRx = DataFormatter.formatBytes(this@DataUsageActivity, mobileUsage.rxBytes)
                val mobileTx = DataFormatter.formatBytes(this@DataUsageActivity, mobileUsage.txBytes)
                binding.tvMobileRxTx.text = "تحميل: $mobileRx | رفع: $mobileTx"

                // شبكة Wi-Fi
                binding.tvWifiTotal.text = DataFormatter.formatBytes(this@DataUsageActivity, wifiUsage.totalBytes)
                val wifiRx = DataFormatter.formatBytes(this@DataUsageActivity, wifiUsage.rxBytes)
                val wifiTx = DataFormatter.formatBytes(this@DataUsageActivity, wifiUsage.txBytes)
                binding.tvWifiRxTx.text = "تحميل: $wifiRx | رفع: $wifiTx"

                // جلب بيانات المخطط البياني لآخر 7 أيام
                val chartDays = helper.queryLast7DaysUsage()
                binding.chartLast7Days.setData(chartDays)

            } catch (_: Exception) {
                Toast.makeText(this@DataUsageActivity, R.string.usage_query_error, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadAppUsageForTab(tabIndex: Int) {
        binding.pbLoadingApps.visibility = View.VISIBLE
        binding.tvNoUsageData.visibility = View.GONE
        binding.rvAppUsage.visibility = View.GONE

        lifecycleScope.launch {
            val (startTime, endTime) = getTimeRangeForTab(tabIndex)
            val appUsageList = try {
                helper.queryAppsUsage(startTime, endTime)
            } catch (e: Exception) {
                emptyList()
            }

            binding.pbLoadingApps.visibility = View.GONE
            if (appUsageList.isEmpty()) {
                binding.tvNoUsageData.visibility = View.VISIBLE
                binding.rvAppUsage.visibility = View.GONE
            } else {
                binding.tvNoUsageData.visibility = View.GONE
                binding.rvAppUsage.visibility = View.VISIBLE
                usageAdapter.submitList(appUsageList)
            }
        }
    }

    private fun getTimeRangeForTab(tabIndex: Int): Pair<Long, Long> {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        return when (tabIndex) {
            0 -> {
                // اليوم: من 00:00 اليوم إلى الآن
                Pair(cal.timeInMillis, now)
            }
            1 -> {
                // أمس: من 00:00 أمس إلى 00:00 اليوم
                val startOfToday = cal.timeInMillis
                cal.add(Calendar.DAY_OF_YEAR, -1)
                val startOfYesterday = cal.timeInMillis
                Pair(startOfYesterday, startOfToday)
            }
            2 -> {
                // آخر 7 أيام
                cal.add(Calendar.DAY_OF_YEAR, -6)
                Pair(cal.timeInMillis, now)
            }
            3 -> {
                // هذا الشهر: من أول يوم في الشهر الحالي إلى الآن
                cal.set(Calendar.DAY_OF_MONTH, 1)
                Pair(cal.timeInMillis, now)
            }
            else -> Pair(cal.timeInMillis, now)
        }
    }
}
