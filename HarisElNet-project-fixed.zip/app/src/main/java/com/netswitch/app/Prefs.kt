package com.netswitch.app

import android.content.Context
import android.content.SharedPreferences

/**
 * مدير إعدادات التطبيق وتخزين حزم التطبيقات المحددة للحظر أو الاستثناء،
 * بالإضافة لإعدادات الحد اليومي للاستهلاك والتنبيهات.
 */
class Prefs private constructor(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isVpnActive: Boolean
        get() = sharedPreferences.getBoolean(KEY_VPN_ACTIVE, false)
        set(value) = sharedPreferences.edit().putBoolean(KEY_VPN_ACTIVE, value).apply()

    var isBlockAllExceptSelected: Boolean
        get() = sharedPreferences.getBoolean(KEY_BLOCK_ALL, false)
        set(value) = sharedPreferences.edit().putBoolean(KEY_BLOCK_ALL, value).apply()

    // توافقية الاسم المستعار
    var isBlockAllEnabled: Boolean
        get() = isBlockAllExceptSelected
        set(value) {
            isBlockAllExceptSelected = value
        }

    var blockedPackages: Set<String>
        get() = sharedPreferences.getStringSet(KEY_BLOCKED_APPS, emptySet()) ?: emptySet()
        set(value) = sharedPreferences.edit().putStringSet(KEY_BLOCKED_APPS, value).apply()

    /**
     * إرجاع مجموعة أسماء الحزم المحظورة أو المحددة.
     * يُرجع Set<String> ليتوافق مع جميع الاستدعاءات في BlockerVpnService وباقي الخدمات.
     */
    fun getBlockedApps(): Set<String> {
        return blockedPackages
    }

    /**
     * تحديث قائمة الحزم المحظورة بالكامل.
     */
    fun setBlockedApps(packageNames: Collection<String>) {
        blockedPackages = packageNames.toSet()
    }

    // الحد اليومي لبيانات الجوال بالميجابايت (0 يعني غير مفعّل)
    var dailyMobileLimitMb: Long
        get() = sharedPreferences.getLong(KEY_DAILY_MOBILE_LIMIT_MB, 0L)
        set(value) = sharedPreferences.edit().putLong(KEY_DAILY_MOBILE_LIMIT_MB, value).apply()

    // تتبع التنبيهات التي تم إرسالها اليوم لتجنب تكرار الإشعار
    var lastAlert80Day: String
        get() = sharedPreferences.getString(KEY_LAST_ALERT_80_DAY, "") ?: ""
        set(value) = sharedPreferences.edit().putString(KEY_LAST_ALERT_80_DAY, value).apply()

    var lastAlert100Day: String
        get() = sharedPreferences.getString(KEY_LAST_ALERT_100_DAY, "") ?: ""
        set(value) = sharedPreferences.edit().putString(KEY_LAST_ALERT_100_DAY, value).apply()

    fun setAppBlocked(packageName: String, blocked: Boolean) {
        val currentSet = blockedPackages.toMutableSet()
        if (blocked) {
            currentSet.add(packageName)
        } else {
            currentSet.remove(packageName)
        }
        blockedPackages = currentSet
    }

    fun isAppBlocked(packageName: String): Boolean {
        return blockedPackages.contains(packageName)
    }

    fun setAllAppsBlocked(packageNames: Collection<String>) {
        blockedPackages = packageNames.toSet()
    }

    fun clearAllBlockedApps() {
        blockedPackages = emptySet()
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sharedPreferences.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val PREFS_NAME = "haris_el_net_prefs"
        const val KEY_VPN_ACTIVE = "key_vpn_active"
        const val KEY_BLOCK_ALL = "key_block_all"
        const val KEY_BLOCKED_APPS = "key_blocked_apps"
        const val KEY_DAILY_MOBILE_LIMIT_MB = "key_daily_mobile_limit_mb"
        const val KEY_LAST_ALERT_80_DAY = "key_last_alert_80_day"
        const val KEY_LAST_ALERT_100_DAY = "key_last_alert_100_day"

        @Volatile
        private var instance: Prefs? = null

        fun getInstance(context: Context): Prefs {
            return instance ?: synchronized(this) {
                instance ?: Prefs(context.applicationContext).also { instance = it }
            }
        }
    }
}
