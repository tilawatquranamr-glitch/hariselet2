package com.netswitch.app

import android.content.Context
import android.text.format.Formatter
import java.text.NumberFormat
import java.util.Locale

/**
 * فئة مساعدة لتنسيق أحجام البيانات وأرقام الاستهلاك طبقاً للغة وإعدادات الجهاز.
 */
object DataFormatter {

    /**
     * تنسيق حجم البيانات بالبايت إلى KB / MB / GB تلقائياً بواسطة نظام أندرويد
     * مع احترام تنسيق الأرقام واللغة المحددة في النظام.
     */
    fun formatBytes(context: Context, bytes: Long): String {
        return Formatter.formatFileSize(context, bytes)
    }

    /**
     * تنسيق النسبة المئوية بالأرقام المنسقة (مثلاً: 25.4%).
     */
    fun formatPercentage(percentage: Float): String {
        val nf = NumberFormat.getNumberInstance(Locale.getDefault())
        nf.maximumFractionDigits = 1
        return "${nf.format(percentage)}%"
    }
}
