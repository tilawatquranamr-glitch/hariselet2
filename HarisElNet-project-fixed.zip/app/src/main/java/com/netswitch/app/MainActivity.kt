package com.netswitch.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.netswitch.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * الشاشة الرئيسية لتطبيق "حارس النت" (Haris El Net).
 * تمتاز بتصميم كلاسيكي ورقي عريق وأنيق مع الحفاظ الكامل على كافة الوظائف البرمجية وعزل تطبيقات النظام.
 * معززة بـ Global Crash Log Viewer و try/catch لحماية دورة الحياة ومنع أي شاشة فارغة.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var appAdapter: AppAdapter

    // خدمات النظام الحرجة المستبعدة دائماً من القائمة ومن عمليات الحظر
    private val criticalSystemPackages = setOf(
        "com.google.android.gms",
        "com.android.vending",
        "com.google.android.gsf"
    )

    // مستمع لتغيرات SharedPreferences لتحديث الواجهة فوراً عند تغيير الخدمة للحالة
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.KEY_VPN_ACTIVE || key == Prefs.KEY_BLOCK_ALL) {
            runOnUiThread {
                try {
                    updateUiState()
                } catch (e: Exception) {
                    Log.e(TAG, "Error in prefsListener updateUiState", e)
                }
            }
        }
    }

    // إطلاق طلب إذن الـ VPN
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startVpn()
        } else {
            Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_SHORT).show()
            updateUiState()
        }
    }

    // طلب إذن الإشعارات لأجهزة أندرويد 13+ (API 33+)
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // إذن عرض الإشعار المستمر للخدمة
    }

    // مستقبل بث لتحديث حالة الـ VPN عند التشغيل أو التوقف
    private val vpnStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BlockerVpnService.ACTION_VPN_STATE_CHANGED) {
                try {
                    updateUiState()
                } catch (e: Exception) {
                    Log.e(TAG, "Error in vpnStateReceiver updateUiState", e)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)

            prefs = Prefs.getInstance(this)

            checkAndDisplayPreviousCrash()
            setupRecyclerView()
            setupListeners()
            loadInstalledUserApps()
            checkNotificationPermission()
        } catch (t: Throwable) {
            Log.e(TAG, "Fatal error inside onCreate", t)
            NetSwitchApplication.saveCrash(this, t)
            displayFatalErrorFallback(t)
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            prefs.registerListener(prefsListener)
            updateUiState()
        } catch (e: Exception) {
            Log.e(TAG, "Error in onStart", e)
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            updateUiState()
            registerVpnReceiver()
        } catch (e: Exception) {
            Log.e(TAG, "Error in onResume", e)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(vpnStateReceiver)
        } catch (_: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        try {
            prefs.unregisterListener(prefsListener)
        } catch (e: Exception) {}
    }

    /**
     * التحقق من وجود تقرير انهيار سابق محفوظ في SharedPreferences وعرضه
     */
    private fun checkAndDisplayPreviousCrash() {
        try {
            val crashReport = NetSwitchApplication.getLastCrash(this)
            if (!crashReport.isNullOrEmpty()) {
                binding.cardCrashBanner.visibility = View.VISIBLE
                binding.tvCrashLog.text = crashReport

                binding.btnCopyCrash.setOnClickListener {
                    try {
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("NetSwitch Crash Log", crashReport)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(this, R.string.crash_copied_toast, Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Failed to copy: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }

                binding.btnDismissCrash.setOnClickListener {
                    NetSwitchApplication.clearLastCrash(this)
                    binding.cardCrashBanner.visibility = View.GONE
                }
            } else {
                binding.cardCrashBanner.visibility = View.GONE
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check previous crash", e)
        }
    }

    /**
     * في حال فشل التضخيم أو التهيئة في onCreate، إنشاء واجهة بديلة بسيطة لعرض الخطأ بالكامل
     */
    private fun displayFatalErrorFallback(throwable: Throwable) {
        try {
            val layout = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setBackgroundColor(0xFFF6EFDF.toInt())
                setPadding(32, 48, 32, 48)
            }

            val title = android.widget.TextView(this).apply {
                text = "حارس النت - خطأ في تهيئة الواجهة"
                setTextColor(0xFF8C2F2B.toInt())
                textSize = 18f
                setTypeface(null, Typeface.BOLD)
            }

            val desc = android.widget.TextView(this).apply {
                text = "حدث خطأ غير متوقع أثناء فتح الشاشة. تفاصيل الخطأ أدناه قابلة للنسخ:"
                setTextColor(0xFF2B2118.toInt())
                textSize = 14f
                setPadding(0, 16, 0, 16)
            }

            val errorBox = android.widget.TextView(this).apply {
                text = Log.getStackTraceString(throwable)
                setTextIsSelectable(true)
                setTextColor(0xFF14463A.toInt())
                setBackgroundColor(0xFFFFFBF2.toInt())
                setPadding(24, 24, 24, 24)
                textSize = 12f
                typeface = Typeface.MONOSPACE
            }

            val btnCopy = android.widget.Button(this).apply {
                text = "نسخ تفاصيل الخطأ"
                setOnClickListener {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Crash Log", Log.getStackTraceString(throwable)))
                    Toast.makeText(this@MainActivity, "تم النسخ بنجاح", Toast.LENGTH_SHORT).show()
                }
            }

            layout.addView(title)
            layout.addView(desc)
            layout.addView(btnCopy)
            layout.addView(errorBox)
            setContentView(layout)
        } catch (e: Exception) {
            Log.e(TAG, "Failed even fallback view", e)
        }
    }

    private fun registerVpnReceiver() {
        val filter = IntentFilter(BlockerVpnService.ACTION_VPN_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(vpnStateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(vpnStateReceiver, filter)
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupRecyclerView() {
        appAdapter = AppAdapter(packageManager, emptyList()) { appItem, isBlocked ->
            prefs.setAppBlocked(appItem.packageName, isBlocked)
            if (prefs.isVpnActive) {
                BlockerVpnService.startService(this)
            }
        }

        binding.rvApps.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = appAdapter
            setHasFixedSize(true)
        }
    }

    private fun setupListeners() {
        // الزر الدائري الرئيسي الكبير (112dp)
        binding.btnMainPower.setOnClickListener {
            if (prefs.isVpnActive) {
                stopVpn()
            } else {
                prepareAndStartVpn()
            }
        }

        // زر إعادة المحاولة عند حدوث خطأ في تحميل التطبيقات
        binding.btnRetryLoadApps.setOnClickListener {
            loadInstalledUserApps()
        }

        // مفتاح Switch المخفي للحفاظ على التزامن في حال تغييره برمجياً
        binding.switchMainVpn.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!prefs.isVpnActive) prepareAndStartVpn()
            } else {
                if (prefs.isVpnActive) stopVpn()
            }
        }

        // التحكم في اختيار الوضع (Segmented Control)
        binding.btnModeSelective.setOnClickListener {
            if (prefs.isBlockAllEnabled) {
                prefs.isBlockAllEnabled = false
                updateSegmentedControlUi(false)
                updateModeLabels(false)
                if (prefs.isVpnActive) {
                    BlockerVpnService.startService(this)
                }
            }
        }

        binding.btnModeBlockAll.setOnClickListener {
            if (!prefs.isBlockAllEnabled) {
                prefs.isBlockAllEnabled = true
                updateSegmentedControlUi(true)
                updateModeLabels(true)
                if (prefs.isVpnActive) {
                    BlockerVpnService.startService(this)
                }
            }
        }

        // زر تحديد الكل
        binding.btnSelectAll.setOnClickListener {
            appAdapter.selectAll {
                for (app in appAdapter.getAllApps()) {
                    if (app.isBlocked) {
                        prefs.setAppBlocked(app.packageName, true)
                    }
                }
                if (prefs.isVpnActive) {
                    BlockerVpnService.startService(this)
                }
            }
        }

        // زر إلغاء التحديد
        binding.btnDeselectAll.setOnClickListener {
            appAdapter.deselectAll {
                prefs.clearAllBlockedApps()
                if (prefs.isVpnActive) {
                    BlockerVpnService.startService(this)
                }
            }
        }

        // البحث اللحظي في التطبيقات بالاسم أو الحزمة
        binding.searchApps.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                appAdapter.filter(query.orEmpty())
                updateEmptyStateVisibility()
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                appAdapter.filter(newText.orEmpty())
                updateEmptyStateVisibility()
                return true
            }
        })

        // أزرار الشريط السفلي الكلاسيكي
        binding.navItemProtection.setOnClickListener {
            // الشاشة الحالية
        }

        binding.navItemUsage.setOnClickListener {
            val intent = Intent(this, DataUsageActivity::class.java)
            startActivity(intent)
        }

        binding.navItemSim.setOnClickListener {
            Toast.makeText(this, R.string.tab_sim, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateEmptyStateVisibility() {
        if (appAdapter.itemCount == 0 && binding.layoutAppsError.visibility != View.VISIBLE) {
            binding.tvAppsEmpty.visibility = View.VISIBLE
        } else {
            binding.tvAppsEmpty.visibility = View.GONE
        }
    }

    private fun updateSegmentedControlUi(isBlockAll: Boolean) {
        if (isBlockAll) {
            binding.btnModeBlockAll.setBackgroundResource(R.drawable.bg_segmented_active)
            binding.btnModeBlockAll.setTextColor(ContextCompat.getColor(this, R.color.surface_card))
            binding.btnModeBlockAll.setTypeface(null, Typeface.BOLD)

            binding.btnModeSelective.setBackgroundResource(R.drawable.bg_segmented_inactive)
            binding.btnModeSelective.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
            binding.btnModeSelective.setTypeface(null, Typeface.NORMAL)
        } else {
            binding.btnModeSelective.setBackgroundResource(R.drawable.bg_segmented_active)
            binding.btnModeSelective.setTextColor(ContextCompat.getColor(this, R.color.surface_card))
            binding.btnModeSelective.setTypeface(null, Typeface.BOLD)

            binding.btnModeBlockAll.setBackgroundResource(R.drawable.bg_segmented_inactive)
            binding.btnModeBlockAll.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
            binding.btnModeBlockAll.setTypeface(null, Typeface.NORMAL)
        }
    }

    private fun updateModeLabels(isBlockAll: Boolean) {
        if (isBlockAll) {
            binding.tvAppsSectionTitle.text = getString(R.string.apps_section_title_allowed)
        } else {
            binding.tvAppsSectionTitle.text = getString(R.string.apps_section_title_blocked)
        }
    }

    private fun prepareAndStartVpn() {
        checkNotificationPermission()
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            startVpn()
        }
    }

    private fun startVpn() {
        BlockerVpnService.startService(this)
        updateUiState()
    }

    private fun stopVpn() {
        BlockerVpnService.stopService(this)
        updateUiState()
    }

    private fun updateUiState() {
        val isActive = prefs.isVpnActive

        // تحديث مظهر الزر الدائري الرئيسي الكلاسيكي ونصوص الحالة
        if (isActive) {
            binding.btnMainPower.setBackgroundResource(R.drawable.bg_main_button_active)
            binding.tvStatus.text = getString(R.string.status_blocking_active)
            binding.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.danger_red))
            binding.tvStatusSubtitle.text = getString(R.string.status_blocking_active_subtitle)
        } else {
            binding.btnMainPower.setBackgroundResource(R.drawable.bg_main_button_inactive)
            binding.tvStatus.text = getString(R.string.status_net_normal)
            binding.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.primary_dark_green))
            binding.tvStatusSubtitle.text = getString(R.string.status_net_normal_subtitle)
        }

        // مزامنة حالة المفاتيح الخلفية
        binding.switchMainVpn.setOnCheckedChangeListener(null)
        binding.switchMainVpn.isChecked = isActive
        binding.switchMainVpn.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) prepareAndStartVpn() else stopVpn()
        }

        binding.switchBlockAll.isChecked = prefs.isBlockAllEnabled

        // تحديث مظهر الـ Segmented Control
        updateSegmentedControlUi(prefs.isBlockAllEnabled)
        updateModeLabels(prefs.isBlockAllEnabled)
    }

    /**
     * معيار فحص تطبيق المستخدم:
     * يُعتبر تطبيق مستخدم إذا لم يكن تطبيق نظام،
     * أو كان تطبيق نظام محدثاً (FLAG_UPDATED_SYSTEM_APP) وله أيقونة تشغيل في الواجهة.
     */
    private fun isUserApp(pm: PackageManager, appInfo: ApplicationInfo): Boolean {
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        val hasLaunchIntent = pm.getLaunchIntentForPackage(appInfo.packageName) != null
        return !isSystem || (isUpdatedSystem && hasLaunchIntent)
    }

    /**
     * تحميل تطبيقات المستخدم فقط مع الحماية الكاملة بـ try/catch
     * وعرض أي خطأ على الشاشة بدلاً من تركها فارغة.
     */
    private fun loadInstalledUserApps() {
        binding.progressBar.visibility = View.VISIBLE
        binding.layoutAppsError.visibility = View.GONE
        binding.tvAppsEmpty.visibility = View.GONE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val pm = packageManager
                val packages = pm.getInstalledApplications(0)

                val appList = mutableListOf<AppItem>()
                val ownPackage = packageName

                for (appInfo in packages) {
                    // 1. استبعاد تطبيقنا نفسه
                    if (appInfo.packageName == ownPackage) continue

                    // 2. استبعاد خدمات النظام الحرجة
                    if (criticalSystemPackages.contains(appInfo.packageName)) continue

                    // 3. التحقق الدقيق: إدراج تطبيقات المستخدم فقط
                    if (!isUserApp(pm, appInfo)) continue

                    val appName = try {
                        pm.getApplicationLabel(appInfo).toString()
                    } catch (_: Exception) {
                        appInfo.packageName
                    }
                    val isBlocked = prefs.isAppBlocked(appInfo.packageName)

                    appList.add(
                        AppItem(
                            name = appName,
                            packageName = appInfo.packageName,
                            isBlocked = isBlocked
                        )
                    )
                }

                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    appAdapter.updateData(appList)
                    updateEmptyStateVisibility()
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Error loading installed apps", t)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.layoutAppsError.visibility = View.VISIBLE
                    binding.tvAppsErrorMessage.text = t.localizedMessage ?: t.toString()
                    updateEmptyStateVisibility()
                }
            }
        }
    }
}
