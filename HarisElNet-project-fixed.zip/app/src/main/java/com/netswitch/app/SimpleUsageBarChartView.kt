package com.netswitch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * ويدجت مخصص لرسم مخطط بياني للأعمدة لآخر 7 أيام باستخدام Canvas مباشرة،
 * متوافق تماماً مع الطابع الكلاسيكي العريق (أخضر غامق #14463A وذهبي #B08A3E وفاصل #E8DCBF).
 */
class SimpleUsageBarChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var dayUsages: List<DayUsage> = emptyList()

    // لون الأعمدة العادية: ذهبي دافئ
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B08A3E")
        style = Paint.Style.FILL
    }

    // لون عمود اليوم الحالي: أخضر غامق وقور
    private val activeBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#14463A")
        style = Paint.Style.FILL
    }

    // خط الأساس والشبكة: بيج هادئ #E8DCBF
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8DCBF")
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    // أسماء الأيام: نص ثانوي #6F6252
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6F6252")
        textSize = 28f
        textAlign = Paint.Align.CENTER
    }

    // قيم الاستهلاك: نص أساسي #2B2118
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2B2118")
        textSize = 24f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val barRect = RectF()

    fun setData(data: List<DayUsage>) {
        this.dayUsages = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (dayUsages.isEmpty()) return

        val paddingLeft = paddingLeft.toFloat() + 20f
        val paddingRight = paddingRight.toFloat() + 20f
        val paddingTop = paddingTop.toFloat() + 30f
        val paddingBottom = paddingBottom.toFloat() + 50f

        val availableWidth = width.toFloat() - paddingLeft - paddingRight
        val availableHeight = height.toFloat() - paddingTop - paddingBottom

        if (availableWidth <= 0 || availableHeight <= 0) return

        // رسم خط الأساس الأفقي
        val baselineY = paddingTop + availableHeight
        canvas.drawLine(paddingLeft, baselineY, paddingLeft + availableWidth, baselineY, gridPaint)

        val maxUsage = (dayUsages.maxOfOrNull { it.totalBytes } ?: 0L).coerceAtLeast(1L)
        val count = dayUsages.size
        val barGroupWidth = availableWidth / count
        val barWidth = (barGroupWidth * 0.55f).coerceAtLeast(16f)

        for (i in 0 until count) {
            val item = dayUsages[i]
            val centerX = paddingLeft + (i * barGroupWidth) + (barGroupWidth / 2f)

            // حساب ارتفاع العمود نسبة لأعلى يوم
            val ratio = (item.totalBytes.toFloat() / maxUsage.toFloat()).coerceIn(0f, 1f)
            val barHeight = (availableHeight * ratio).coerceAtLeast(if (item.totalBytes > 0) 8f else 0f)

            val left = centerX - (barWidth / 2f)
            val right = centerX + (barWidth / 2f)
            val top = baselineY - barHeight
            val bottom = baselineY

            barRect.set(left, top, right, bottom)
            // اليوم الأخير (اليوم الحالي) بلون أخضر غامق مميز والأيام السابقة بالذهبي
            val currentPaint = if (i == count - 1) activeBarPaint else barPaint
            canvas.drawRoundRect(barRect, 6f, 6f, currentPaint)

            // كتابة اسم اليوم أسفل خط الأساس
            canvas.drawText(item.dayLabel, centerX, baselineY + 36f, textPaint)

            // كتابة القيمة فوق العمود إن كانت أكبر من صفر
            if (item.totalBytes > 0) {
                val formattedVal = DataFormatter.formatBytes(context, item.totalBytes)
                canvas.drawText(formattedVal, centerX, (top - 10f).coerceAtLeast(paddingTop), valuePaint)
            }
        }
    }
}
