package com.netswitch.app

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.netswitch.app.databinding.ItemAppUsageBinding

/**
 * محوّل قائمة استهلاك التطبيقات.
 * يعرض اسم التطبيق، أيقونته، إجمالي الاستهلاك، ونسبة مئوية مع شريط تقدم نسبي.
 */
class AppUsageAdapter(
    private val packageManager: PackageManager
) : RecyclerView.Adapter<AppUsageAdapter.UsageViewHolder>() {

    private val items = mutableListOf<AppUsageItem>()
    private val defaultIcon: Drawable? = null

    fun submitList(newItems: List<AppUsageItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsageViewHolder {
        val binding = ItemAppUsageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return UsageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UsageViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class UsageViewHolder(
        private val binding: ItemAppUsageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AppUsageItem) {
            val context = binding.root.context
            binding.tvAppName.text = item.appName
            binding.tvTotalUsage.text = DataFormatter.formatBytes(context, item.totalBytes)
            binding.tvPercentage.text = DataFormatter.formatPercentage(item.percentageOfTotal)

            // شريط التقدم من 1000 نقطة لدقة أفضل
            val progressInt = (item.percentageOfTotal * 10f).toInt().coerceIn(0, 1000)
            binding.pbUsage.progress = progressInt

            val rxFormatted = DataFormatter.formatBytes(context, item.rxBytes)
            val txFormatted = DataFormatter.formatBytes(context, item.txBytes)
            binding.tvUsageBreakdown.text = "تحميل: $rxFormatted | رفع: $txFormatted"

            // تحميل الأيقونة عند الربط فقط خفيفاً على الذاكرة
            val icon = try {
                packageManager.getApplicationIcon(item.packageName)
            } catch (_: Exception) {
                ContextCompat.getDrawable(context, R.drawable.ic_launcher)
            }
            binding.ivAppIcon.setImageDrawable(icon)
        }
    }
}
