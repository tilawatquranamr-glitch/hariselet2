package com.netswitch.app

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * خدمة Quick Settings Tile لعرض والتحكم في حالة مفتاح النت من لوحة الإعدادات السريعة.
 */
class NetSwitchTile : TileService() {

    private lateinit var prefs: Prefs

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.KEY_VPN_ACTIVE) {
            updateTileState()
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.getInstance(this)
    }

    override fun onStartListening() {
        super.onStartListening()
        prefs.registerListener(prefsListener)
        updateTileState()
    }

    override fun onStopListening() {
        prefs.unregisterListener(prefsListener)
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()

        // التحقق من منح صلاحية الـ VPN أولاً
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            // الصلاحية غير ممنوحة: فتح MainActivity لطلب الإذن من المستخدم
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
            return
        }

        // الصلاحية ممنوحة بالفعل: تبديل حالة الحظر فوراً
        if (prefs.isVpnActive) {
            BlockerVpnService.stopService(this)
        } else {
            BlockerVpnService.startService(this)
        }

        // تحديث المظهر المرئي للزر فوراً
        updateTileState()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val isActive = prefs.isVpnActive

        tile.state = if (isActive) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_label)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (isActive) {
                getString(R.string.tile_status_active)
            } else {
                getString(R.string.tile_status_inactive)
            }
        }

        tile.updateTile()
    }
}
