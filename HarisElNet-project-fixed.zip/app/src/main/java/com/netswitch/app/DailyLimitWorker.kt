package com.netswitch.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * عامل WorkManager دوري يعمل كل 15 دقيقة لمراقبة حد استهلاك بيانات الجوال اليومي.
 * يرسل إشعاراً عند الوصول إلى 80% وإشعاراً عند الوصول إلى 100%.
 */
class DailyLimitWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val prefs = Prefs.getInstance(context)
        val limitMb = prefs.dailyMobileLimitMb

        // إذا لم يكن هناك حد يومي محدد، ننهي العمل بنجاح
        if (limitMb <= 0L) {
            return Result.success()
        }

        val helper = NetworkStatsHelper(context)
        if (!helper.hasUsageStatsPermission()) {
            return Result.success()
        }

        // استعلام استهلاك اليوم من 00:00 حتى اللحظة
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfDay = cal.timeInMillis
        val now = System.currentTimeMillis()

        val mobileStats = helper.querySummaryForNetwork(
            ConnectivityManager.TYPE_MOBILE,
            startOfDay,
            now
        )

        val usedBytes = mobileStats.totalBytes
        val limitBytes = limitMb * 1024L * 1024L

        val todayDateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Calendar.getInstance().time)

        // التحقق من وصول نسبة 100%
        if (usedBytes >= limitBytes) {
            if (prefs.lastAlert100Day != todayDateStr) {
                showLimitNotification(
                    id = 2001,
                    title = context.getString(R.string.usage_limit_alert_100_title),
                    content = context.getString(R.string.usage_limit_alert_100_desc, limitMb)
                )
                prefs.lastAlert100Day = todayDateStr
            }
        } else if (usedBytes >= (limitBytes * 0.8).toLong()) {
            // التحقق من وصول نسبة 80%
            if (prefs.lastAlert80Day != todayDateStr) {
                val formattedUsed = DataFormatter.formatBytes(context, usedBytes)
                showLimitNotification(
                    id = 2002,
                    title = context.getString(R.string.usage_limit_alert_80_title),
                    content = context.getString(R.string.usage_limit_alert_80_desc, formattedUsed, limitMb, 80)
                )
                prefs.lastAlert80Day = todayDateStr
            }
        }

        return Result.success()
    }

    private fun showLimitNotification(id: Int, title: String, content: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

        val channelId = CHANNEL_ID

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                context.getString(R.string.usage_alert_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.usage_alert_channel_desc)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, DataUsageActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(id, notification)
    }

    companion object {
        const val CHANNEL_ID = "channel_usage_alerts"
        const val UNIQUE_WORK_NAME = "haris_daily_limit_work"
    }
}
