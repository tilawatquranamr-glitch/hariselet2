package com.netswitch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * خدمة الـ VPN لتطبيق "حارس النت" (Haris El Net).
 * تقطع الإنترنت عن تطبيقات المستخدم فقط مع إبقاء تطبيقات وخدمات النظام متصلة دائماً.
 */
class BlockerVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private lateinit var prefs: Prefs

    // خدمات النظام الحرجة التي يجب أن تتجاوز الحظر وتبقى متصلة دائماً
    private val criticalSystemPackages = setOf(
        "com.google.android.gms",
        "com.android.vending",
        "com.google.android.gsf"
    )

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.getInstance(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action ?: ACTION_START) {
            ACTION_START -> startVpn()
            ACTION_STOP -> {
                stopVpn()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    /**
     * معيار التمييز بين تطبيقات المستخدم وتطبيقات النظام:
     * يُعتبر تطبيق مستخدم إذا:
     * (flags & FLAG_SYSTEM) == 0 أو كان تطبيق نظام محدثاً (FLAG_UPDATED_SYSTEM_APP) وله أيقونة تشغيل
     */
    private fun isUserApp(pm: PackageManager, appInfo: ApplicationInfo): Boolean {
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        val hasLaunchIntent = pm.getLaunchIntentForPackage(appInfo.packageName) != null
        return !isSystem || (isUpdatedSystem && hasLaunchIntent)
    }

    private fun startVpn() {
        stopVpn()
        startForegroundServiceWithNotification()

        try {
            var allowedCount = 0
            val builder = Builder().apply {
                setSession("Haris El Net")
                addAddress("10.111.222.1", 32)
                addRoute("0.0.0.0", 0)
                try {
                    addRoute("::", 0)
                } catch (e: IllegalArgumentException) {
                    Log.w(TAG, "IPv6 route not supported", e)
                }
                setMtu(1500)

                val pm = packageManager

                if (prefs.isBlockAllEnabled) {
                    // استثناء تطبيقنا نفسه دائماً ليبقى قادراً على العمل والتحكم
                    // (addDisallowedApplication لا يجوز خلطها مع addAllowedApplication في نفس الـ Builder)
                    try {
                        addDisallowedApplication(packageName)
                    } catch (e: PackageManager.NameNotFoundException) {
                        Log.e(TAG, "Own package not found", e)
                    }

                    // الوضع 1: وضع "قطع الكل ما عدا المحدد":
                    // المرور على كل التطبيقات المثبتة عبر getInstalledApplications(0)
                    // وكل تطبيق ليس "تطبيق مستخدم" أو كان محدداً بالسماح، يُستدعى له addDisallowedApplication
                    // حتى يتجاوز الـ VPN ويبقى متصلاً، وبذلك يُقطع فقط تطبيقات المستخدم غير المحددة.
                    val installedApps = pm.getInstalledApplications(0)
                    val allowedApps = prefs.getBlockedApps() // في هذا الوضع، التطبيقات المحددة بالقائمة تمثل المسموح لها

                    for (app in installedApps) {
                        if (app.packageName == packageName) continue

                        val isUser = isUserApp(pm, app)
                        val isCritical = criticalSystemPackages.contains(app.packageName)
                        val isExplicitlyAllowed = allowedApps.contains(app.packageName)

                        // يستثنى ليتجاوز الـ VPN ويبقى متصلاً إذا لم يكن تطبيق مستخدم أو كان خدمة حرجة أو كان محدداً بالسماح
                        val shouldBypass = !isUser || isCritical || isExplicitlyAllowed

                        if (shouldBypass) {
                            try {
                                addDisallowedApplication(app.packageName)
                            } catch (e: PackageManager.NameNotFoundException) {
                                Log.w(TAG, "NameNotFoundException bypassing: ${app.packageName}", e)
                            }
                        }
                    }
                } else {
                    // الوضع 2: وضع "حظر المحدد فقط":
                    // يوجّه الحزم عبر الـ VPN للتطبيقات المحددة فقط عبر addAllowedApplication
                    // مع التأكد القاطع من أن التطبيق المحدد ليس من تطبيقات النظام ولا الخدمات الحرجة
                    val targets = prefs.getBlockedApps()
                    for (pkg in targets) {
                        if (criticalSystemPackages.contains(pkg) || pkg == packageName) continue

                        try {
                            val appInfo = pm.getApplicationInfo(pkg, 0)
                            if (isUserApp(pm, appInfo)) {
                                addAllowedApplication(pkg)
                                allowedCount++
                            }
                        } catch (e: PackageManager.NameNotFoundException) {
                            Log.w(TAG, "NameNotFoundException targeting: $pkg", e)
                        }
                    }
                }
            }

            // في وضع "حظر المحدد فقط": لو مفيش أي تطبيق صالح، الـ VPN كان هيشمل كل التطبيقات (يقطع كل النت)
            // فنوقف التشغيل بدل ما نقطع الإنترنت عن الجميع بالغلط.
            if (!prefs.isBlockAllEnabled && allowedCount == 0) {
                Log.w(TAG, "No valid apps selected; not starting VPN")
                prefs.isVpnActive = false
                broadcastState(false)
                stopForeground(true)
                stopSelf()
                return
            }

            vpnInterface = builder.establish()
            if (vpnInterface != null) {
                prefs.isVpnActive = true
                broadcastState(true)
            } else {
                stopSelf()
            }
        } catch (e: Exception) {
            Log.e(TAG, "VPN Start failed", e)
            stopSelf()
        }
    }

    private fun stopVpn() {
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing descriptor", e)
        } finally {
            vpnInterface = null
            prefs.isVpnActive = false
            broadcastState(false)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.cancel(NOTIFICATION_ID)
        }
    }

    private fun startForegroundServiceWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            manager?.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = Intent(this, BlockerVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopServiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreAction = NotificationCompat.Action.Builder(
            0,
            getString(R.string.notification_action_restore_net),
            stopPendingIntent
        ).build()

        val statusDescription = if (prefs.isBlockAllEnabled) {
            getString(R.string.status_all_blocked)
        } else {
            getString(R.string.status_selective_blocked, prefs.getBlockedApps().size)
        }

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.notification_title_blocked))
            .setContentText(statusDescription)
            .setContentIntent(openAppIntent)
            .addAction(restoreAction)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun broadcastState(isRunning: Boolean) {
        val intent = Intent(ACTION_VPN_STATE_CHANGED).apply {
            putExtra(EXTRA_IS_RUNNING, isRunning)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onRevoke() {
        stopVpn()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BlockerVpnService"
        private const val CHANNEL_ID = "haris_el_net_channel"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.netswitch.app.ACTION_START"
        const val ACTION_STOP = "com.netswitch.app.ACTION_STOP"
        const val ACTION_VPN_STATE_CHANGED = "com.netswitch.app.ACTION_VPN_STATE_CHANGED"
        const val EXTRA_IS_RUNNING = "extra_is_running"

        fun startService(context: Context) {
            val intent = Intent(context, BlockerVpnService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, BlockerVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
