package com.netswitch.app

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.netswitch.app.databinding.ItemAppBinding

/**
 * نموذج بيانات التطبيق: خفيف جداً على الذاكرة بدون الاحتفاظ بـ Drawable مسبقاً.
 */
data class AppItem(
    val name: String,
    val packageName: String,
    var isBlocked: Boolean
)

/**
 * محول قائمة تطبيقات المستخدم مع دعم البحث اللحظي وفرز المحظور للأعلى وتحميل الأيقونات عند الربط.
 */
class AppAdapter(
    private val packageManager: PackageManager,
    private var masterApps: List<AppItem>,
    private val onToggleBlock: (AppItem, Boolean) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    private var filteredApps: MutableList<AppItem> = mutableListOf()
    private var currentFilterQuery: String = ""

    init {
        applyFilterAndSort(masterApps, "")
    }

    inner class AppViewHolder(val binding: ItemAppBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = filteredApps[position]
        with(holder.binding) {
            tvAppName.text = app.name
            tvPackageName.text = app.packageName

            // تحميل خفيف للأيقونة عند الربط فقط لحماية الذاكرة وتجنب OutOfMemory
            try {
                val icon = packageManager.getApplicationIcon(app.packageName)
                ivAppIcon.setImageDrawable(icon)
            } catch (e: Exception) {
                ivAppIcon.setImageResource(R.drawable.ic_launcher)
            }

            // فك المستمع أولاً لتجنب إطلاق أحداث خاطئة عند إعادة التدوير
            switchBlock.setOnCheckedChangeListener(null)
            switchBlock.isChecked = app.isBlocked

            switchBlock.setOnCheckedChangeListener { _, isChecked ->
                app.isBlocked = isChecked
                onToggleBlock(app, isChecked)

                // إعادة الفرز لوضع التطبيقات المحددة في أعلى القائمة
                applyFilterAndSort(masterApps, currentFilterQuery)
            }
        }
    }

    override fun getItemCount(): Int = filteredApps.size

    fun updateData(newApps: List<AppItem>) {
        this.masterApps = newApps
        applyFilterAndSort(masterApps, currentFilterQuery)
    }

    fun filter(query: String) {
        currentFilterQuery = query
        applyFilterAndSort(masterApps, currentFilterQuery)
    }

    fun selectAll(onChanged: () -> Unit) {
        for (item in filteredApps) {
            item.isBlocked = true
        }
        applyFilterAndSort(masterApps, currentFilterQuery)
        onChanged()
    }

    fun deselectAll(onChanged: () -> Unit) {
        for (item in filteredApps) {
            item.isBlocked = false
        }
        applyFilterAndSort(masterApps, currentFilterQuery)
        onChanged()
    }

    fun getAllApps(): List<AppItem> = masterApps

    private fun applyFilterAndSort(source: List<AppItem>, query: String) {
        val trimmed = query.trim().lowercase()

        // 1. فلترة البحث بالاسم أو الحزمة
        val searchFiltered = if (trimmed.isEmpty()) {
            source
        } else {
            source.filter {
                it.name.lowercase().contains(trimmed) ||
                it.packageName.lowercase().contains(trimmed)
            }
        }

        // 2. فرز: التطبيقات المحددة في الأعلى، ثم أبجدياً بالاسم
        val sorted = searchFiltered.sortedWith(
            compareByDescending<AppItem> { it.isBlocked }
                .thenBy { it.name.lowercase() }
        )

        filteredApps.clear()
        filteredApps.addAll(sorted)
        notifyDataSetChanged()
    }
}
