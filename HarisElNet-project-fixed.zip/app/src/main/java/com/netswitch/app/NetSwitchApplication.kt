package com.netswitch.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

/**
 * فئة التطبيق الرئيسية لتطبيق "حارس النت" (Haris El Net).
 * تحتوي على معالج استثناءات عام (Global Uncaught Exception Handler)
 * يقوم بتسجيل أي انهيار أو استثناء غير معالج وحفظ الـ Stacktrace في SharedPreferences،
 * لكي تتمكن MainActivity من عرضه للمستخدم على الشاشة في نص قابل للنسخ بدلاً من الشاشة الفارغة.
 */
class NetSwitchApplication : Application() {

    companion object {
        const val PREFS_CRASH = "netswitch_crashes"
        const val KEY_LAST_CRASH = "key_last_crash_trace"
        const val KEY_LAST_CRASH_TIMESTAMP = "key_last_crash_timestamp"
        private const val TAG = "NetSwitchApp"

        fun getLastCrash(context: Context): String? {
            val sp = context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE)
            return sp.getString(KEY_LAST_CRASH, null)
        }

        fun clearLastCrash(context: Context) {
            val sp = context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE)
            sp.edit().remove(KEY_LAST_CRASH).remove(KEY_LAST_CRASH_TIMESTAMP).apply()
        }

        fun saveCrash(context: Context, throwable: Throwable) {
            try {
                val sw = StringWriter()
                val pw = PrintWriter(sw)
                throwable.printStackTrace(pw)
                val stackTraceString = sw.toString()

                val sp = context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE)
                sp.edit()
                    .putString(KEY_LAST_CRASH, stackTraceString)
                    .putLong(KEY_LAST_CRASH_TIMESTAMP, System.currentTimeMillis())
                    .apply()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save crash report", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e(TAG, "Uncaught exception caught in global crash handler", throwable)
                saveCrash(this, throwable)
            } catch (e: Exception) {
                Log.e(TAG, "Error handling uncaught exception", e)
            } finally {
                // تمرير المعالجة للمعالج الافتراضي للنظام إذا لزم الأمر
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
