package com.netswitch.app

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Process
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

data class NetworkUsageSummary(
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L
) {
    val totalBytes: Long get() = rxBytes + txBytes
}

data class DayUsage(
    val dayLabel: String,
    val dateEpochMs: Long,
    val totalBytes: Long
)

data class AppUsageItem(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val rxBytes: Long,
    val txBytes: Long,
    val totalBytes: Long,
    val percentageOfTotal: Float
)

/**
 * فئة إدارة واستعلام استهلاك الإنترنت الحقيقي عبر NetworkStatsManager.
 */
class NetworkStatsHelper(private val context: Context) {

    private val networkStatsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as? NetworkStatsManager

    /**
     * التحقق مما إذا كانت صلاحية PACKAGE_USAGE_STATS ممنوحة عبر AppOpsManager.
     */
    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * الحصول على معرّف الشريحة (subscriberId) لأجهزة أندرويد 9 فما دون
     * بينما لأجهزة أندرويد 10+ (API 29+) يمرر null كمعيار قياسي للنظام.
     */
    @SuppressLint("HardwareIds", "MissingPermission")
    private fun getSubscriberId(): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return null
        }
        return try {
            val telephonyManager =
                context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            telephonyManager?.subscriberId
        } catch (_: SecurityException) {
            null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * استعلام ملخص استهلاك شبكة معينة (جوال أو واي فاي) خلال فترة زمنية محددة.
     */
    suspend fun querySummaryForNetwork(
        networkType: Int,
        startTime: Long,
        endTime: Long
    ): NetworkUsageSummary = withContext(Dispatchers.IO) {
        val manager = networkStatsManager ?: return@withContext NetworkUsageSummary()
        try {
            val subscriberId = if (networkType == ConnectivityManager.TYPE_MOBILE) {
                getSubscriberId()
            } else {
                null
            }

            val bucket = manager.querySummaryForDevice(networkType, subscriberId, startTime, endTime)
            NetworkUsageSummary(
                rxBytes = bucket.rxBytes,
                txBytes = bucket.txBytes
            )
        } catch (_: Exception) {
            NetworkUsageSummary()
        }
    }

    /**
     * استعلام تفاصيل استهلاك كل تطبيق (querySummary) وتجميعه حسب UID
     * ثم تحويله إلى قائمة مرتبة تنازلياً مع أسماء وأيقونات التطبيقات.
     */
    suspend fun queryAppsUsage(
        startTime: Long,
        endTime: Long
    ): List<AppUsageItem> = withContext(Dispatchers.IO) {
        val manager = networkStatsManager ?: return@withContext emptyList()
        val pm = context.packageManager
        val uidUsageMap = mutableMapOf<Int, Pair<Long, Long>>() // uid -> (rx, tx)

        // جلب استهلاك بيانات الجوال لكل تطبيق
        try {
            val subscriberId = getSubscriberId()
            val mobileStats = manager.querySummary(
                ConnectivityManager.TYPE_MOBILE,
                subscriberId,
                startTime,
                endTime
            )
            aggregateBuckets(mobileStats, uidUsageMap)
        } catch (_: Exception) {}

        // جلب استهلاك Wi-Fi لكل تطبيق
        try {
            val wifiStats = manager.querySummary(
                ConnectivityManager.TYPE_WIFI,
                null,
                startTime,
                endTime
            )
            aggregateBuckets(wifiStats, uidUsageMap)
        } catch (_: Exception) {}

        val totalAllAppsBytes = uidUsageMap.values.sumOf { it.first + it.second }
        val resultList = mutableListOf<AppUsageItem>()

        for ((uid, stats) in uidUsageMap) {
            // استبعاد معرّفات النظام الخاصة المشتركة إذا لم تكن لتطبيق محدد
            if (uid < Process.FIRST_APPLICATION_UID && uid != Process.SYSTEM_UID) {
                continue
            }

            val rx = stats.first
            val tx = stats.second
            val total = rx + tx
            if (total <= 0) continue

            val packages = pm.getPackagesForUid(uid)
            val primaryPackage = packages?.firstOrNull() ?: "uid_$uid"

            val appName = try {
                if (packages != null && packages.isNotEmpty()) {
                    val appInfo = pm.getApplicationInfo(primaryPackage, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } else if (uid == Process.SYSTEM_UID) {
                    "نظام أندرويد (OS)"
                } else {
                    "تطبيق ($uid)"
                }
            } catch (_: Exception) {
                primaryPackage
            }

            val percentage = if (totalAllAppsBytes > 0) {
                (total.toFloat() / totalAllAppsBytes.toFloat()) * 100f
            } else {
                0f
            }

            resultList.add(
                AppUsageItem(
                    packageName = primaryPackage,
                    appName = appName,
                    uid = uid,
                    rxBytes = rx,
                    txBytes = tx,
                    totalBytes = total,
                    percentageOfTotal = percentage
                )
            )
        }

        // الترتيب التنازلي بالأكثر استهلاكاً
        resultList.sortByDescending { it.totalBytes }
        resultList
    }

    private fun aggregateBuckets(
        stats: NetworkStats?,
        uidUsageMap: MutableMap<Int, Pair<Long, Long>>
    ) {
        if (stats == null) return
        val bucket = NetworkStats.Bucket()
        while (stats.hasNextBucket()) {
            stats.getNextBucket(bucket)
            val uid = bucket.uid
            val rx = bucket.rxBytes
            val tx = bucket.txBytes

            val current = uidUsageMap[uid] ?: Pair(0L, 0L)
            uidUsageMap[uid] = Pair(current.first + rx, current.second + tx)
        }
        stats.close()
    }

    /**
     * استعلام استهلاك كل يوم لآخر 7 أيام لرسم المخطط البياني.
     */
    suspend fun queryLast7DaysUsage(): List<DayUsage> = withContext(Dispatchers.IO) {
        val result = mutableListOf<DayUsage>()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        // الأيام السبعة بما فيها اليوم
        for (i in 6 downTo 0) {
            val dayCal = cal.clone() as Calendar
            dayCal.add(Calendar.DAY_OF_YEAR, -i)
            val dayStart = dayCal.timeInMillis

            val nextDayCal = dayCal.clone() as Calendar
            nextDayCal.add(Calendar.DAY_OF_YEAR, 1)
            val dayEnd = if (i == 0) System.currentTimeMillis() else nextDayCal.timeInMillis

            val mobile = querySummaryForNetwork(ConnectivityManager.TYPE_MOBILE, dayStart, dayEnd)
            val wifi = querySummaryForNetwork(ConnectivityManager.TYPE_WIFI, dayStart, dayEnd)
            val totalBytes = mobile.totalBytes + wifi.totalBytes

            val dayOfWeekStr = when (dayCal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SATURDAY -> "السبت"
                Calendar.SUNDAY -> "الأحد"
                Calendar.MONDAY -> "الإثنين"
                Calendar.TUESDAY -> "الثلاثاء"
                Calendar.WEDNESDAY -> "الأربعاء"
                Calendar.THURSDAY -> "الخميس"
                Calendar.FRIDAY -> "الجمعة"
                else -> ""
            }

            result.add(
                DayUsage(
                    dayLabel = dayOfWeekStr,
                    dateEpochMs = dayStart,
                    totalBytes = totalBytes
                )
            )
        }

        result
    }
}
