# قواعد ProGuard الآمنة لتطبيق Haris El Net

# الحفاظ على نموذج ViewBinding
-keepclassmembers class * implements androidx.viewbinding.ViewBinding {
    public static * inflate(...);
    public static * bind(...);
}

# الحفاظ على عمال WorkManager
-keep public class * extends androidx.work.ListenableWorker {
    public <init>(...);
}

# الحفاظ على خدمات النظام والـ VPN
-keep public class com.netswitch.app.BlockerVpnService { *; }
-keep public class com.netswitch.app.NetSwitchTile { *; }
-keep public class com.netswitch.app.DailyLimitWorker { *; }
-keep public class com.netswitch.app.SimpleUsageBarChartView { *; }
