plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.netswitch.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.netswitch.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // قراءة بيانات التوقيع بأمان من gradle.properties أو متغيرات البيئة
    val keystorePath = (project.findProperty("KEYSTORE_FILE") as? String)
        ?: System.getenv("KEYSTORE_FILE")
    val keystorePassword = (project.findProperty("KEYSTORE_PASSWORD") as? String)
        ?: System.getenv("KEYSTORE_PASSWORD")
    val keyAlias = (project.findProperty("KEY_ALIAS") as? String)
        ?: System.getenv("KEY_ALIAS")
    val keyPassword = (project.findProperty("KEY_PASSWORD") as? String)
        ?: System.getenv("KEY_PASSWORD")

    signingConfigs {
        if (!keystorePath.isNullOrEmpty() && !keystorePassword.isNullOrEmpty() &&
            !keyAlias.isNullOrEmpty() && !keyPassword.isNullOrEmpty()) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = keystorePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            // تطبيق توقيع الـ Release عند توفر إعدادات التوقيع
            signingConfigs.findByName("release")?.let {
                signingConfig = it
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
